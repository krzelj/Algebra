﻿document.addEventListener('DOMContentLoaded', function () {
    // Retrieve notification count from local storage if it exists
    var storedCount = localStorage.getItem('unsentNotificationCount');
    if (storedCount) {
        document.getElementById('notificationCount').textContent = 'Unsent Notifications: ' + storedCount;
    } else {
        fetch('https://localhost:7142/api/notifications/GetUnsentNotificationsCount')
            .then(response => response.text())
            .then(count => {
                document.getElementById('notificationCount').textContent = 'Unsent Notifications: ' + count;

                localStorage.setItem('unsentNotificationCount', count);
            });
    }

    document.getElementById('sendNotificationsButton').addEventListener('click', function () {
        fetch('https://localhost:7142/api/notifications/sendnotifications', { method: 'POST' })
            .then(() => {
                localStorage.removeItem('unsentNotificationCount');
                location.reload();
            });
    });
});
