﻿using API.Database;
using API.Models.Videos;

namespace API.Mapping
{
    public static class TagMapping
    {
        public static IEnumerable<Tag> MapToDAL(IEnumerable<TagRequest> tagRequest) =>
            tagRequest.Select(x => MapToDAL(x));

        public static Tag MapToDAL(TagRequest tagRequest) =>
            new Tag
            {
                Name = tagRequest.Name
            };

        public static IEnumerable<TagResponse> MapToResponse(IEnumerable<Tag> tags) =>
            tags.Select(x => MapToResponse(x));

        public static TagResponse MapToResponse(Tag tag) =>
            new TagResponse
            {
                Id = tag.Id,
                Name = tag.Name
            };
    }
}
