﻿using API.Database;
using API.Models.Videos;

namespace API.Mapping
{
    public static class GenreMapping
    {
        public static IEnumerable<Genre> MapToDAL(IEnumerable<GenreRequest> genreRequest) =>
            genreRequest.Select(x => MapToDAL(x));

        public static Genre MapToDAL(GenreRequest genreRequest) =>
            new Genre
            {
                Name = genreRequest.Name,
                Description = genreRequest.Description
            };

        public static IEnumerable<GenreResponse> MapToResponse(IEnumerable<Genre> genres) =>
            genres.Select(x => MapToResponse(x));

        public static GenreResponse MapToResponse(Genre genre) =>
            new GenreResponse
            {
                Id = genre.Id,
                Name = genre.Name,
                Description = genre.Description
            };
    }
}
