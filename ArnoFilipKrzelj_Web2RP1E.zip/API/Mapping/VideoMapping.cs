﻿using API.Database;
using API.Models.Videos;
using API.Services;

namespace API.Mapping
{
    public static class VideoMapping
    {
        // videorequest => video
        // video => videoresponse
        public static IEnumerable<Video> MapToDAL(IEnumerable<VideoRequest> videoRequests) =>
            videoRequests.Select(x => MapToDAL(x));

        public static Video MapToDAL(VideoRequest videoRequest) =>
            new Video
            {
                Name = videoRequest.Name,
                CreatedAt = videoRequest.CreatedAt,
                Description = videoRequest.Description,
                ImageId = videoRequest.ImageId,
                GenreId = videoRequest.GenreId,
                StreamingUrl = videoRequest.StreamingUrl,
                TotalSeconds = videoRequest.TotalSeconds
            };

        public static IEnumerable<VideoResponse> MapToResponse(IEnumerable<Video> videos) =>
            videos.Select(x => MapToResponse(x));

        public static VideoResponse MapToResponse(Video video) =>
            new VideoResponse
            {
                Id = video.Id,
                Name = video.Name,
                ImageId = video.ImageId,
                GenreId = video.GenreId,
                StreamingUrl = video.StreamingUrl,
                TotalSeconds = video.TotalSeconds,
                Description = video.Description,
                VideoTags = video.VideoTags.ToList(),
            };
    }
}
