﻿using System.ComponentModel.DataAnnotations;

namespace Task06.Models;

public partial class SendNotificationsResponse
{
    public int SuccessCount { get; set; }
    public int FailCount { get; set; }

}
