﻿using System.ComponentModel.DataAnnotations;

namespace Task06.Models;

public partial class NotificationResponse
{
    public int Id { get; set; }

    public Guid Guid { get; set; }

    [Required]
    public string ReceiverEmail { get; set; }

    [Required]
    public string Subject { get; set; }

    [Required]
    public string Body { get; set; }

}
