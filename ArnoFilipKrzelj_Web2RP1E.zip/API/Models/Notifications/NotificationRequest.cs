﻿using System.ComponentModel.DataAnnotations;

namespace Task06.Models;

public partial class NotificationRequest
{
    [StringLength(256)]
    [EmailAddress]
    public string ReceiverEmail { get; set; }

    [StringLength(256)]
    public string Subject { get; set; }

    [StringLength(1024)]
    public string Body { get; set; }
}
