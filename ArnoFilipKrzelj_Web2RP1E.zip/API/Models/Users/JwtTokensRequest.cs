﻿namespace Task04.Model
{
    public class JwtTokensRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
