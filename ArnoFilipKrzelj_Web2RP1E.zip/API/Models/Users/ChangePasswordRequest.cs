﻿using System.ComponentModel.DataAnnotations;

namespace Task04.Model
{
    public class ChangePasswordRequest
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string OldPassword { get; set; }
        [Required]
        public string NewPassword { get; set; }
    }
}
