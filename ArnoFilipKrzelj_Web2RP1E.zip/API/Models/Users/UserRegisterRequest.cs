﻿using System.ComponentModel.DataAnnotations;

namespace Task04.Model
{
    public class UserRegisterRequest
    {
        [Required, StringLength(50, MinimumLength = 6)]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [StringLength(256)]
        public string FirstName { get; set; } = null!;
        [StringLength(256)]
        public string LastName { get; set; } = null!;
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Phone]
        public string Phone { get; set; }
        [Required]
        public string Country { get; set; }

        //[Required]
        //public string Role { get; set; }
    }
}
