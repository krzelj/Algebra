﻿namespace Task04.Model
{
    public class UserRegisterResponse
    {
        public int Id { get; set; }
        public string SecurityToken { get; set; }
        public string URL { get; set; }
    }
}
