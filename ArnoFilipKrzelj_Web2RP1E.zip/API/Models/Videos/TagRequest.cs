﻿using System.ComponentModel.DataAnnotations;

namespace API.Models.Videos
{
    public class TagRequest
    {
        [StringLength(50)]
        public string Name { get; set; } = null!;
    }
}
