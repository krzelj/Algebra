﻿using System.ComponentModel.DataAnnotations;

namespace API.Models.Videos
{
    public class GenreResponse
    {
        public int Id { get; set; }

        [StringLength(256)]
        public string Name { get; set; } = null!;

        [StringLength(1024)]
        public string? Description { get; set; }
    }
}
