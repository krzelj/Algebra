﻿using API.Database;
using System.ComponentModel.DataAnnotations;

namespace API.Models.Videos
{
    public class VideoResponse
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; }

        [StringLength(256)]
        public string Name { get; set; } = null!;

        [StringLength(1024)]
        public string? Description { get; set; }

        public int GenreId { get; set; }

        public int TotalSeconds { get; set; }

        [StringLength(256)]
        public string? StreamingUrl { get; set; }

        public int? ImageId { get; set; }

        public List<VideoTag>? VideoTags { get; set; }
    }
}
