﻿using API.Database;
using API.Mapping;
using API.Models.Videos;
using API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class VideosController : ControllerBase
    {
        private readonly IRepository<Video> _repository;

        public VideosController(IRepository<Video> _repository)
        {
            this._repository = _repository;
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<VideoResponse>> GetAll()
        {
            try
            {
                return Ok(_repository.Retrieve().Select(v => VideoMapping.MapToResponse(v)));
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("[action]")]
        public ActionResult<VideoResponse> Get(int id)
        {
            try
            {
                var video = _repository.Retrieve().FirstOrDefault(e => e.Id == id);

                if (video is null)
                {
                    return NotFound();
                }

                return Ok(VideoMapping.MapToResponse(video));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<VideoResponse>> GetByPaging(int page, int size)
        {
            try
            {
                if (page < 0 || size < 0)
                {
                    return BadRequest("Page and size must be non-negative.");
                }

                var videos = _repository
                    .Retrieve()
                    .Skip(page * size)
                    .Take(size)
                    .Select(v => VideoMapping.MapToResponse(v));

                return Ok(videos);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<VideoResponse>> FilterByName(string name)
        {
            try
            {
                var videos = _repository
                    .Retrieve()
                    .Select(v => VideoMapping.MapToResponse(v));

                return Ok(videos.Where(video => video.Name.Contains(name)));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<VideoResponse>> OrderBy(string order)
        {
            try
            {
                if (string.IsNullOrEmpty(order))
                {
                    return BadRequest("The 'order' parameter is required.");
                }

                var videos = _repository.Retrieve();
                switch (order.ToLower())
                {
                    case "id":
                        videos = videos.OrderBy(v => v.Id);
                        break;
                    case "name":
                        videos = videos.OrderBy(v => v.Name);
                        break;
                    case "totalseconds":
                        videos = videos.OrderBy(v => v.TotalSeconds);
                        break;
                    default:
                        return BadRequest("Invalid order by parameter.");
                }
                return Ok(VideoMapping.MapToResponse(videos));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("[action]")]
        public ActionResult<VideoResponse> Create(VideoRequest video)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var created = _repository.Create(VideoMapping.MapToDAL(video));

                return Ok(VideoMapping.MapToResponse(created));
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPut("[action]")]
        public ActionResult<VideoResponse> Update(int id, VideoRequest video)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var updated = _repository.Update(id, VideoMapping.MapToDAL(video));

                if (updated is null)
                {
                    return NotFound();
                }

                return Ok(VideoMapping.MapToResponse(updated));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpDelete("[action]")]
        public ActionResult<VideoResponse> Delete(int id)
        {
            try
            {
                var deleted = _repository.Delete(id);

                if (deleted is null)
                {
                    return NotFound();
                }

                return Ok(VideoMapping.MapToResponse(deleted));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
