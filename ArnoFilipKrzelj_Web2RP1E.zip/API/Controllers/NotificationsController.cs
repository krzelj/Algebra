﻿using API.Database;
using API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using Task06.Models;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        private readonly INotificationRepository _dbContext;
        public NotificationsController(INotificationRepository _dbContext)
        {
            this._dbContext = _dbContext;
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<NotificationResponse>> GetAll()
        {
            try
            {
                var notificationResponses =
                   _dbContext
                    .Retrieve()
                    .Select(notification =>
                    new NotificationResponse
                    {
                        Id = notification.Id,
                        ReceiverEmail = notification.ReceiverEmail,
                        Subject = notification.Subject,
                        Body = notification.Body
                    });
                return Ok(notificationResponses);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("{id}")]
        public ActionResult<NotificationResponse> Get(int id)
        {
            try
            {
                var notification = _dbContext.Retrieve().FirstOrDefault(n => n.Id == id);
                
                if (notification == null)
                {
                    return NotFound();
                }

                return Ok(new NotificationResponse
                {
                    Id = notification.Id,
                    ReceiverEmail = notification.ReceiverEmail,
                    Subject = notification.Subject,
                    Body = notification.Body
                });
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("[action]")]
        public ActionResult<int> GetUnsentNotificationsCount()
        {
            try
            {
                int count = _dbContext.Retrieve().Where(n => n.SentAt is null).Count();
                return Ok(count);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("[action]")]
        public ActionResult<NotificationResponse> Create(NotificationRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var dbNotification = new Notification
                {
                    ReceiverEmail = request.ReceiverEmail,
                    Subject = request.Subject,
                    Body = request.Body,
                    CreatedAt = DateTime.UtcNow,
                };

                _dbContext.Create(dbNotification);

                return Ok(new NotificationResponse
                {
                    Id = dbNotification.Id,
                    ReceiverEmail = dbNotification.ReceiverEmail,
                    Subject = dbNotification.Subject,
                    Body = dbNotification.Body
                });
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPut("{id}")]
        public ActionResult<NotificationResponse> Modify(int id, [FromBody] NotificationRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var updated = _dbContext.Update(id, new Notification
                {
                    ReceiverEmail = request.ReceiverEmail,
                    Subject = request.Subject,
                    Body = request.Body
                });

                if (updated is null)
                {
                    return NotFound();
                }

                return Ok(new NotificationResponse
                {
                    Id = updated.Id,
                    ReceiverEmail = updated.ReceiverEmail,
                    Subject = updated.Subject,
                    Body = updated.Body
                });
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<NotificationResponse> Remove(int id)
        {
            try
            {
                var removed = _dbContext.Delete(id);
                
                if (removed == null)
                {
                    return NotFound();
                }

                return Ok(new NotificationResponse
                {
                    Id = removed.Id,
                    ReceiverEmail = removed.ReceiverEmail,
                    Subject = removed.Subject,
                    Body = removed.Body
                });
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("[action]")]
        public ActionResult SendAllNotifications()
        {
            try
            {
                _dbContext.SendAllNotifications();

                return Ok();
            }
            catch (Exception exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

        [HttpPost("[action]/{count}")]
        public ActionResult<SendNotificationsResponse> SendNotificationBatch(int count)
        {
            try {

                var send = _dbContext.SendNotificationBatch(count);

                return Ok(send);
            }
            catch (Exception exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, exception.Message);
            }
        }

    }
}
