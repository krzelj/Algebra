﻿using API.Database;
using API.Services;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task04.Model;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _repository;
        private readonly INotificationRepository notifications;
        public UsersController(IUserRepository _repository, INotificationRepository notifications)
        {
            this._repository = _repository;
            this.notifications = notifications;
        }

        [HttpPost("[action]")]
        public ActionResult<UserRegisterResponse> Register([FromBody] UserRegisterRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var user = _repository.Add(request);

                var validateUrl = $"https://{Request.Host}/api/users/ValidateEmail?username={user.Username}&token={user.SecurityToken}";

                var dbNotification = new Notification
                {
                    ReceiverEmail = request.Email,
                    Subject = $"Validate account for {request.Username}",
                    Body = validateUrl,
                    CreatedAt = DateTime.UtcNow,
                };

                notifications.Create(dbNotification);

                return Ok(new UserRegisterResponse
                {
                    Id = user.Id,
                    SecurityToken = user.SecurityToken,
                    URL = validateUrl
                });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("[action]")]
        public ActionResult ValidateEmail([FromQuery] string username, [FromQuery] string token)
        {
            try
            {
                _repository.ValidateEmail(new ValidateEmailRequest { Username = username, B64SecToken = token });

                return Ok(new ValidateEmailRequest
                {
                    Username = username,
                    B64SecToken = token
                });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost("[action]")]
        public ActionResult<ValidateEmailRequest> ValidateEmail([FromBody] ValidateEmailRequest request)
        {
            try
            {
                _repository.ValidateEmail(request);

                return Ok(request);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("[action]")]
        public ActionResult<Tokens> JwtTokens([FromBody] JwtTokensRequest request)
        {
            try
            {
                return Ok(_repository.JwtTokens(request));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("[action]")]
        public ActionResult ChangePassword([FromBody] ChangePasswordRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Please provide all the necessary information.");
                }

                _repository.ChangePassword(request);
                return Ok();
            }
            catch (Exception e) 
            { 
                return BadRequest(e.Message); 
            }
        }
    }
}
