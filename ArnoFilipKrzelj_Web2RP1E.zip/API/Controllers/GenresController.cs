﻿using API.Database;
using API.Mapping;
using API.Models.Videos;
using API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenresController : ControllerBase
    {
        private readonly IRepository<Genre> _repository;

        public GenresController(IRepository<Genre> _repository)
        {
            this._repository = _repository;
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<GenreResponse>> GetAll()
        {
            try
            {
                return Ok(_repository.Retrieve().Select(g => GenreMapping.MapToResponse(g)));//.Select(g => GenreMapping.MapToBL(g)));
            }
            catch 
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("[action]")]
        public ActionResult<GenreResponse> Create(GenreRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var genre = _repository.Create(GenreMapping.MapToDAL(model));

                return Ok(GenreMapping.MapToResponse(genre));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        
        [HttpPut("[action]")]
        public ActionResult<GenreResponse> Update(int id, GenreRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var updated = _repository.Update(id, GenreMapping.MapToDAL(model));

                if (updated is null)
                {
                    return NotFound();
                }

                return Ok(GenreMapping.MapToResponse(updated));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpDelete("[action]")]
        public ActionResult<GenreResponse> Delete(int id)
        {
            try
            {
                var deleted = _repository.Delete(id);

                if (deleted is null)
                {
                    return NotFound();
                }

                return Ok(GenreMapping.MapToResponse(deleted));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
