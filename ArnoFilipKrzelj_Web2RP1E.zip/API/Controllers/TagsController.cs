﻿using API.Database;
using API.Mapping;
using API.Models.Videos;
using API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TagsController : ControllerBase
    {
        private readonly IRepository<Tag> _repository;

        public TagsController(IRepository<Tag> _repository)
        {
            this._repository = _repository;
        }

        [HttpGet("[action]")]
        public ActionResult<IEnumerable<TagResponse>> GetAll()
        {
            try
            {
                return Ok(_repository.Retrieve().Select(t => TagMapping.MapToResponse(t)));//.Select(t => TagMapping.MapToBL(t)));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("[action]")]
        public ActionResult<TagResponse> Create(TagRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var created = _repository.Create(TagMapping.MapToDAL(model));

                return Ok(TagMapping.MapToResponse(created));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPut("[action]")]
        public ActionResult<TagResponse> Update(int id, TagRequest model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var updated = _repository.Update(id, TagMapping.MapToDAL(model));

                if (updated is null)
                {
                    return NotFound();
                }

                return Ok(TagMapping.MapToResponse(updated));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpDelete("[action]")]
        public ActionResult<TagResponse> Delete(int id)
        {
            try
            {
                var deleted = _repository.Delete(id);

                if (deleted is null)
                {
                    return NotFound();
                }
                
                return Ok(TagMapping.MapToResponse(deleted));
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
