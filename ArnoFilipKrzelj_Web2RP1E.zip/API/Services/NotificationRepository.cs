﻿using API.Database;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using Task06.Models;

namespace API.Services
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly DwaMovies database;
        private readonly IConfiguration configuration;
        public NotificationRepository(DwaMovies database, IConfiguration configuration)
        {
            this.database = database;
            this.configuration = configuration;
        }
        public Notification Create(Notification model)
        {
            model.CreatedAt = DateTime.Now;

            database.Notifications.Add(model);
            database.SaveChanges();

            return model;
        }

        public Notification Delete(int id)
        {
            var notification = database.Notifications.FirstOrDefault(v => v.Id == id);

            if (notification is null)
            {
                return null;
            }

            database.Notifications.Remove(notification);
            database.SaveChanges();

            return notification;
        }

        public IEnumerable<Notification> Retrieve()
        {
            return database.Notifications;
        }

        public void SendAllNotifications()
        {
            try
            {
                var client = new SmtpClient(configuration["NotificationsSettings:Ip"], int.Parse(configuration["NotificationsSettings:Port"]));
                var sender = configuration["NotificationsSettings:Sender"];

                var unsent =
                    database
                    .Notifications
                    .Where(x => !x.SentAt.HasValue);

                foreach (var notification in unsent)
                {
                    try
                    {
                        var mail = new MailMessage(
                            from: new MailAddress(sender),
                            to: new MailAddress(notification.ReceiverEmail));

                        mail.Subject = notification.Subject;
                        mail.Body = notification.Body;

                        client.Send(mail);

                        notification.SentAt = DateTime.UtcNow;
                        database.SaveChanges();
                    }
                    catch
                    {

                    }
                }
            }
            catch 
            {
                throw new Exception("Failed to configure SMTP client.");
            }
        }

        public SendNotificationsResponse SendNotificationBatch(int count)
        {
            try
            {
                var client = new SmtpClient(configuration["NotificationsSettings:Ip"], int.Parse(configuration["NotificationsSettings:Port"]));
                var sender = configuration["NotificationsSettings:Sender"];

                var unsent =
                    database.Notifications
                        .Where(x => !x.SentAt.HasValue)
                        .OrderBy(x => x.CreatedAt)
                        .AsQueryable()
                        .Take(count);

                int success = 0, fail = 0;

                foreach (var notification in unsent)
                {
                    try
                    {
                        var mail = new MailMessage(
                            from: new MailAddress(sender),
                            to: new MailAddress(notification.ReceiverEmail));

                        mail.Subject = notification.Subject;
                        mail.Body = notification.Body;

                        client.Send(mail);

                        notification.SentAt = DateTime.UtcNow;
                        database.SaveChanges();

                        success++;
                    }
                    catch 
                    {
                        fail++;
                    }
                }

                return new SendNotificationsResponse
                {
                    SuccessCount = success,
                    FailCount = fail
                };
            } catch 
            {
                throw new Exception("Failed to configure SMTP client.");
            }
        }

        public Notification Update(int id, Notification model)
        {
            var notification = database.Notifications.FirstOrDefault(v => v.Id == id);

            if (notification is null)
            {
                return null;
            }

            notification.ReceiverEmail = model.ReceiverEmail;
            notification.Subject = model.Subject;
            notification.Body = model.Body;
            
            database.SaveChanges();

            return notification;
        }
    }
}
