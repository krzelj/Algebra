﻿using API.Database;
using Microsoft.EntityFrameworkCore;

namespace API.Services
{
    public class GenreRepository : IRepository<Genre>
    {
        private readonly DwaMovies database;
        public GenreRepository(DwaMovies database)
        {
            this.database = database;
        }
        public Genre Create(Genre model)
        {
            database.Genres.Add(model);
            database.SaveChanges();

            return model;
        }

        public IEnumerable<Genre> Retrieve()
        {
            return database.Genres
                .Include(g => g.Videos);
        }
        public Genre Update(int id, Genre model)
        {
            var genre = database.Genres.FirstOrDefault(g => g.Id == id);

            if (genre == null)
            {
                return null;
            }

            genre.Name = model.Name;
            genre.Description = model.Description;
            database.SaveChanges();

            return genre;
        }

        public Genre Delete(int id)
        {
            var genre = database.Genres.FirstOrDefault(g => g.Id == id);

            if (genre is null)
            {
                return null;
            }

            database.Genres.Remove(genre);
            database.SaveChanges();

            return genre;
        }
    }
}
