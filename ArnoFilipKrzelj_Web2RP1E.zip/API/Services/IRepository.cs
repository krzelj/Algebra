﻿using API.Database;
using Microsoft.AspNetCore.Mvc;

namespace API.Services
{
    public interface IRepository<T>
    {
        IEnumerable<T> Retrieve();
        T Create(T model);
        T Update(int id, T model);
        T Delete(int id);
    }
}
