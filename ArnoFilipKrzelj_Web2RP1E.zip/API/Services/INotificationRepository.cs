﻿using API.Database;
using Task06.Models;

namespace API.Services
{
    public interface INotificationRepository : IRepository<Notification>
    {
        void SendAllNotifications();
        SendNotificationsResponse SendNotificationBatch(int count);
    }
}
