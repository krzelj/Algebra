﻿using API.Database;
using Task04.Model;

namespace API.Services
{
    public interface IUserRepository
    {
        User Add(UserRegisterRequest request);
        //User Update(UserRegisterRequest request);
        //User Delete(UserRegisterRequest request);
        //User Get(UserRegisterRequest request);
        void ValidateEmail(ValidateEmailRequest request);
        Tokens JwtTokens(JwtTokensRequest request);
        void ChangePassword(ChangePasswordRequest request);
    }
}
