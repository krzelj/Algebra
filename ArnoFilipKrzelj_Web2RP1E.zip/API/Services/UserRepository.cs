﻿using API.Database;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Task04.Model;

namespace API.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly DwaMovies database;
        private readonly IConfiguration configuration;
        public UserRepository(DwaMovies database, IConfiguration configuration)
        {
            this.database = database;
            this.configuration = configuration;
        }
        // creates a new user (without validated email)
        public User Add(UserRegisterRequest request)
        {
            try
            {
                string username = request.Username.ToLower().Trim();

                if (database.Users.Any(x => x.Username.Equals(username)))
                {
                    throw new Exception($"Username '{username}' already exists");
                }

                byte[] salt = RandomNumberGenerator.GetBytes(128 / 8);
                string b64Salt = Convert.ToBase64String(salt);

                byte[] hash = KeyDerivation.Pbkdf2(
                        password: request.Password,
                        salt: salt,
                        prf: KeyDerivationPrf.HMACSHA256,
                        iterationCount: 100000,
                        numBytesRequested: 256 / 8);

                string b64Hash = Convert.ToBase64String(hash);

                byte[] securityToken = RandomNumberGenerator.GetBytes(256 / 8);
                string b64SecToken = Convert.ToBase64String(securityToken);


                var country = database.Countries.FirstOrDefault(c => c.Name == request.Country || c.Code == request.Country);
                int countryId = country is null ? 1 : country.Id;

                // New user
                var user = new User
                {
                    Username = request.Username,
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    CountryOfResidenceId = countryId,
                    Email = request.Email,
                    Phone = request.Phone,
                    IsConfirmed = false,
                    SecurityToken = b64SecToken,
                    PwdSalt = b64Salt,
                    PwdHash = b64Hash,
                    CreatedAt = DateTime.UtcNow,
                };

                database.Users.Add(user);
                database.SaveChanges();

                return user;
            }
            catch 
            {
                throw new Exception("Failed to create user.");
            }
        }
        // validates user email
        public void ValidateEmail(ValidateEmailRequest request)
        {
            try
            {
                var target = database.Users.FirstOrDefault(x =>
                x.Username == request.Username && x.SecurityToken == request.B64SecToken)
                    ?? throw new Exception();

                target.IsConfirmed = true;
                database.SaveChanges();
            }
            catch 
            {
                throw new Exception("No user found to validate.");
            }
        }
        // validation needed for jwt token & to change password
        private bool Authenticate(string username, string password)
        {
            var target = database.Users.Single(x => x.Username == username);

            if (!target.IsConfirmed || target is null)
            {
                return false;
            }

            byte[] salt = Convert.FromBase64String(target.PwdSalt);
            byte[] hash = Convert.FromBase64String(target.PwdHash);

            byte[] calcHash =
                KeyDerivation.Pbkdf2(
                    password: password,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: 100000,
                    numBytesRequested: 256 / 8);

            return hash.SequenceEqual(calcHash);
        }
        //public string GetRole(string username)
        //{
        //    var target = database.Users.Single(x => x.Username == username);
        //    return target.Role;
        //}
        public Tokens JwtTokens(JwtTokensRequest request)
        {
            if (!Authenticate(request.Username, request.Password))
            {
                throw new Exception("Authentication failed.");
            }

            var jwtKey = configuration["JWT:Key"];
            var jwtKeyBytes = Encoding.UTF8.GetBytes(jwtKey);
            //var role = GetRole(request.Username);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new System.Security.Claims.Claim[]
                {
                    new System.Security.Claims.Claim(ClaimTypes.Name, request.Username),
                    new System.Security.Claims.Claim(JwtRegisteredClaimNames.Sub, request.Username),
                    //new System.Security.Claims.Claim(ClaimTypes.Role, role)
                }),
                Issuer = configuration["JWT:Issuer"],
                Audience = configuration["JWT:Audience"],
                Expires = DateTime.UtcNow.AddMinutes(10),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(jwtKeyBytes),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var serializedToken = tokenHandler.WriteToken(token);

            return new Tokens
            {
                Token = serializedToken
            };
        }
        public void ChangePassword(ChangePasswordRequest request)
        {
            if (!Authenticate(request.Username, request.OldPassword))
            {
                throw new Exception("Request to change password failed.");
            }

            byte[] salt = RandomNumberGenerator.GetBytes(128 / 8); 
            string b64Salt = Convert.ToBase64String(salt);

            byte[] hash =
                KeyDerivation.Pbkdf2(
                    password: request.NewPassword,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: 100000,
                    numBytesRequested: 256 / 8);
            string b64Hash = Convert.ToBase64String(hash);

            var target = database.Users.Single(x => x.Username == request.Username);
            target.PwdSalt = b64Salt;
            target.PwdHash = b64Hash;
            database.SaveChanges();
        }
    }
}
