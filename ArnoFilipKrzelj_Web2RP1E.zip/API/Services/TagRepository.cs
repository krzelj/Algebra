﻿using API.Database;
using Microsoft.EntityFrameworkCore;

namespace API.Services
{
    public class TagRepository : IRepository<Tag>
    {
        private readonly DwaMovies database;
        public TagRepository(DwaMovies database)
        {
            this.database = database;
        }
        public Tag Create(Tag model)
        {
            database.Tags.Add(model);
            database.SaveChanges();

            return model;
        }

        public IEnumerable<Tag> Retrieve()
        {
            return database.Tags
                .Include(t => t.VideoTags);
        }
        public Tag Update(int id, Tag model)
        {
            var tag = database.Tags.FirstOrDefault(t => t.Id == id);

            if (tag == null)
            {
                return null;
            }

            tag.Name = model.Name;
            database.SaveChanges();

            return tag;
        }

        public Tag Delete(int id)
        {
            var tag = database.Tags.FirstOrDefault(t => t.Id == id);

            if (tag is null)
            {
                return null;
            }

            database.Tags.Remove(tag);
            database.SaveChanges();

            return tag;
        }
    }
}
