﻿using API.Database;
using API.Mapping;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Services
{
    public class VideoRepository : IRepository<Video>
    {
        private readonly DwaMovies database;

        public VideoRepository(DwaMovies database)
        {
            this.database = database;
        }

        public Video Create(Video model)
        {
            model.CreatedAt = DateTime.Now;

            database.Videos.Add(model);
            database.SaveChanges();

            return model;
        }

        public IEnumerable<Video> Retrieve()
        {
            return database.Videos
                .Include(v => v.Genre)
                .Include(v => v.VideoTags)
                .Include(v => v.Image);
        }

        public Video Update(int id, Video model)
        {
            var video = database.Videos.FirstOrDefault(v => v.Id == id);

            if (video is null)
            {
                return null;
            }

            video.Name = model.Name;
            video.Description = model.Description;
            video.GenreId = model.GenreId;
            video.TotalSeconds = model.TotalSeconds;
            video.StreamingUrl = model.StreamingUrl;
            video.ImageId = model.ImageId;

            database.SaveChanges();

            return video;
        }

        public Video Delete(int id)
        {
            var video = database.Videos.FirstOrDefault(v => v.Id == id);

            if (video is null)
            {
                return null;
            }

            database.Videos.Remove(video);
            database.SaveChanges();

            return video;
        }
    }
}
