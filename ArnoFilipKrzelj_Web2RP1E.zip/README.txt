Dear professor Krznarić,

Before you start my Web Development project, here's what you need to know:

1. Database Setup: Please set up the database from 'RwaMovies.zip' before you begin. Make sure the 'genres', 'tags', and 'countries' tables have some data. 
This is necessary because you need country data to make an account and genre/tag data to add videos. I'll give you some example data.

INSERT INTO Genre (Name, Description)
VALUES 
('Adventure', 'Movies that involve exciting and unusual experiences or activities'),
('Comedy', 'Movies intended to make the audience laugh'),
('Drama', 'Movies that involve intense, often emotional storylines and characters'),
('Sci-Fi', 'Movies based on imagined future scientific or technological advances and major social or environmental changes');

INSERT INTO Tag (Name)
VALUES 
('Thriller'),
('Fantasy'),
('Mystery'),
('Horror'),
('Sci-Fi'),
('Romance'),
('Crime'),
('Biography'),
('History'),
('Animation'),
('Music'),
('War'),
('Western'),
('Documentary'),
('Sport');

INSERT INTO Country (Code, Name)
VALUES 
('US', 'United States'),
('CA', 'Canada'),
('UK', 'United Kingdom'),
('AU', 'Australia');

2. Email Confirmation: To log in, you must confirm your email first. This is done through an SMTP MailGun client, which is linked to my email. 
If you want to receive the confirmation code from this service, I need to add your email to the list. After that, you must accept the invite. 
Unfortunately, MailGun is a paid service, so I'm using a limited, sandbox account.

3. User Management: I have created the user management page, adhering to the desired outcome specifications. 
To access this page, it is required to create an account with the designated username 'admin'. Once the account is created, the users page will be accessible.

If you have questions, let me know. I'd appreciate your feedback.

Best regards,
Arno Filip Krželj