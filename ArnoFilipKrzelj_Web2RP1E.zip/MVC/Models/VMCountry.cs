﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class VMCountry
    {
        public int Id { get; set; }

        [StringLength(2)]
        [Unicode(false)]
        public string Code { get; set; } = null!;

        [StringLength(256)]
        public string Name { get; set; } = null!;

        public override string ToString() => $"{Name} ({Code})";
    }
}
