﻿namespace MVC.Models
{
    public class VMUserComparerFirstName : IEqualityComparer<VMUser>
    {
        public bool Equals(VMUser x, VMUser y)
        {
            return x.FirstName.Equals(y.FirstName, StringComparison.OrdinalIgnoreCase);
        }

        public int GetHashCode(VMUser obj)
        {
            return obj.FirstName.GetHashCode(StringComparison.OrdinalIgnoreCase);
        }
    }

    public class VMUserComparerLastName : IEqualityComparer<VMUser>
    {
        public bool Equals(VMUser x, VMUser y)
        {
            return x.LastName.Equals(y.LastName, StringComparison.OrdinalIgnoreCase);
        }

        public int GetHashCode(VMUser obj)
        {
            return obj.LastName.GetHashCode(StringComparison.OrdinalIgnoreCase);
        }
    }
}
