﻿namespace MVC.Models
{
    public class VMFilter
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int GenreId { get; set; }
        public int[] SelectedTags { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10; 
    }
}
