﻿using API.Database;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Configuration;

namespace MVC.Models
{
    public class VMVideo
    {
        public int Id { get; set; }

        public DateTime CreatedAt { get; set; }

        [StringLength(256)]
        [Required(ErrorMessage = "Name must not be empty.")]
        public string Name { get; set; } = null!;

        [StringLength(1024)]
        [Required(ErrorMessage = "Description must not be empty.")]
        public string? Description { get; set; }
        [DisplayName("Genre")]
        [Required(ErrorMessage = "You must select a genre.")]
        public int GenreId { get; set; }

        public int TotalSeconds { get; set; }

        [DisplayName("URL")]
        [StringLength(256)]
        [Required(ErrorMessage = "URL must not be empty.")]
        [RegularExpression("^((?:https?:)?\\/\\/)?((?:www|m)\\.)?((?:youtube(-nocookie)?\\.com|youtu.be))(\\/(?:[\\w\\-]+\\?v=|embed\\/|live\\/|v\\/)?)([\\w\\-]+)(\\S+)?$", ErrorMessage = "Use Youtube URL only please.")]
        public string StreamingUrl { get; set; }

        [StringLength(256)]
        [Required(ErrorMessage = "Please include a valid thumbnail.")]
        public Image Image { get; set; }

        public List<VideoTag> VideoTags { get; set; } = new List<VideoTag>();

        public Genre Genre { get; set; }

        [DisplayName("Tags")]
        [Required]
        [MinLength(1, ErrorMessage = "At least one tag is required.")]
        public List<Tag> Tags { get; set; } = new List<Tag>();
    }
}
