﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MVC.Models
{
    public class VMRegister
    {
        [DisplayName("Username")]
        [StringLength(50, MinimumLength = 4)]
        public string Username { get; set; }
        [DisplayName("Password")]
        [StringLength(50, MinimumLength = 4)]
        public string Password { get; set; }

        [DisplayName("Repeated password")]
        [Compare("Password")]
        [StringLength(50, MinimumLength = 4)]
        public string ConfirmPassword { get; set; }

        [DisplayName("First name")]
        [StringLength(50, MinimumLength = 4)]
        public string FirstName { get; set; }
        [DisplayName("Last name")]
        [StringLength(50, MinimumLength = 4)]
        public string LastName { get; set; }

        [DisplayName("E-mail")]
        [EmailAddress]
        [StringLength(256)]
        public string Email { get; set; }

        [DisplayName("Second E-mail")]
        [Compare("Email")]
        [StringLength(256)]
        public string ConfirmEmail { get; set; }

        [StringLength(256)]
        [DisplayName("Phone number")]
        public string? Phone { get; set; }

        [Required]
        [DisplayName("Country")]
        public int CountryId { get; set; }
    }
}
