﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MVC.Models
{
    public class VMConfirmAccount
    {
        [DisplayName("E-mail")]
        [StringLength(50, MinimumLength = 4)]
        [Required(ErrorMessage = "Email can not be empty.")]
        [EmailAddress]
        public string Email { get; set; }
        [DisplayName("Token")]
        [Required(ErrorMessage = "Token must not be empty.")]
        public string SecurityToken { get; set; }
    }
}
