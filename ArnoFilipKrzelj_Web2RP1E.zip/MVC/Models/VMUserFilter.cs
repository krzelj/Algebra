﻿namespace MVC.Models
{
    public class VMUserFilter
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public int CountryId { get; set; }
    }
}
