﻿using Newtonsoft.Json.Serialization;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class VMLogin
    {
        [DisplayName("Username")]
        [StringLength(50, MinimumLength = 4)]
        [Required(ErrorMessage = "Username can not be empty. Must be between 4 and 50 characters.")]
        public string Username { get; set; }

        [DisplayName("Password")]
        [Required(ErrorMessage = "Password is required. Must be between 4 and 50 characters.")]
        [StringLength(50, MinimumLength = 4)]
        public string Password { get; set; }
    }
}
