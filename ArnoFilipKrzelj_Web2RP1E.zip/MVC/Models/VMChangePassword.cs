﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class VMChangePassword
    {
        [DisplayName("Username")]
        [StringLength(50, MinimumLength = 4)]
        [Required(ErrorMessage = "Username can not be empty. Must be between 4 and 50 characters.")]
        public string Username { get; set; }
        [DisplayName("Password")]
        [StringLength(50, MinimumLength = 4)]
        [Required(ErrorMessage = "Password can not be empty. Must be between 4 and 50 characters.")]
        public string Password { get; set; }
        [DisplayName("New Password")]
        [StringLength(50, MinimumLength = 4)]
        public string NewPassword { get; set; }
    }
}
