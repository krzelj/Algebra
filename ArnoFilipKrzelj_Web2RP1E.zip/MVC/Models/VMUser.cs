﻿using API.Database;
using System.ComponentModel.DataAnnotations;

namespace MVC.Models
{
    public class VMUser
    {
        public int Id { get; set; }

        public DateTime CreatedAt { get; set; }

        [StringLength(50)]
        public string Username { get; set; } = null!;

        [StringLength(256)]
        public string FirstName { get; set; } = null!;

        [StringLength(256)]
        public string LastName { get; set; } = null!;
        [StringLength(256)]
        public string Email { get; set; } = null!;

        public string? Password { get; set; }

        [StringLength(256)]
        public string? Phone { get; set; }

        public bool IsConfirmed { get; set; }

        [StringLength(256)]
        public string? SecurityToken { get; set; }
        public VMCountry Country { get; set; }
    }
}
