﻿using API.Database;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MVC.Models
{
    public class VMUpdateVideo
    {
        [StringLength(256)]
        [Required(ErrorMessage = "Name must not be empty.")]
        public string Name { get; set; } = null!;

        [StringLength(1024)]
        [Required(ErrorMessage = "Description must not be empty.")]
        public string? Description { get; set; }
        [DisplayName("Genre")]
        [Required(ErrorMessage = "You must select a genre.")]
        public int GenreId { get; set; }

        public Image Image { get; set; }

        public List<VideoTag> VideoTags { get; set; } = new List<VideoTag>();

        public Genre Genre { get; set; }

        [DisplayName("Tags")]
        [Required]
        [MinLength(1, ErrorMessage = "At least one tag is required.")]
        public List<Tag> Tags { get; set; } = new List<Tag>();
    }
}
