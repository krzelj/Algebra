﻿using API.Database;
using MVC.Models;

namespace MVC.Mapping
{
    public static class CountryMapping
    {
        public static IEnumerable<Country> MapToDAL(IEnumerable<VMCountry> vmCountry) =>
            vmCountry.Select(x => MapToDAL(x));

        public static Country MapToDAL(VMCountry vmCountry) =>
            new Country
            {
                Code = vmCountry.Code,
                Name = vmCountry.Name
            };

        public static IEnumerable<VMCountry> MapToResponse(IEnumerable<Country> country) =>
            country.Select(x => MapToResponse(x));

        public static VMCountry MapToResponse(Country country) =>
            new VMCountry
            {
                Id = country.Id,
                Code = country.Code,
                Name = country.Name,
            };
    }
}
