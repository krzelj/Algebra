﻿using API.Database;
using MVC.Models;

namespace API.Mapping
{
    public static class VideoMapping 
    {
        public static IEnumerable<Video> MapToDAL(IEnumerable<VMVideo> vmVideos) =>
            vmVideos.Select(x => MapToDAL(x));

        public static Video MapToDAL(VMVideo videoRequest) =>
            new Video
            {
                Name = videoRequest.Name,
                CreatedAt = videoRequest.CreatedAt,
                Description = videoRequest.Description,
                Image = videoRequest.Image,
                GenreId = videoRequest.GenreId,
                StreamingUrl = videoRequest.StreamingUrl,
                TotalSeconds = videoRequest.TotalSeconds,
                VideoTags = videoRequest.VideoTags,
            };

        public static IEnumerable<VMVideo> MapToResponse(IEnumerable<Video> videos) =>
            videos.Select(x => MapToResponse(x));

        public static VMVideo MapToResponse(Video video) =>
            new VMVideo
            {
                Id = video.Id,
                CreatedAt = video.CreatedAt,
                Name = video.Name,
                Image = video.Image,
                GenreId = video.GenreId,
                Genre = video.Genre,
                StreamingUrl = video.StreamingUrl,
                TotalSeconds = video.TotalSeconds,
                Description = video.Description,
                // No actual tags, just a relationship table.
                VideoTags = video.VideoTags.ToList(),
                Tags = video.VideoTags.Select(vt => vt.Tag).ToList()
            };
    }
}
