﻿using API.Database;
using MVC.Models;

namespace MVC.Mapping
{
    public static class UserMapping
    {
        public static IEnumerable<VMUser> MapToResponse(IEnumerable<User> users)
            => users.Select(x => MapToResponse(x));

        public static VMUser MapToResponse(User user) =>
            new VMUser
            {
                Id = user.Id,
                CreatedAt = user.CreatedAt,
                Username = user.Username,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Phone = user.Phone,
                IsConfirmed = user.IsConfirmed,
                SecurityToken = user.SecurityToken,
                Country = CountryMapping.MapToResponse(user.CountryOfResidence)
            };
    }
}
