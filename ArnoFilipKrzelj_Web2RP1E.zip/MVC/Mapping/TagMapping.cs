﻿using API.Database;
using MVC.Models;

namespace MVC.Mapping
{
    public static class TagMapping
    {
        public static IEnumerable<Tag> MapToDAL(IEnumerable<VMTag> tagRequest) =>
            tagRequest.Select(x => MapToDAL(x));

        public static Tag MapToDAL(VMTag tagRequest) =>
            new Tag
            {
                Name = tagRequest.Name
            };

        public static IEnumerable<VMTag> MapToResponse(IEnumerable<Tag> tags) =>
            tags.Select(x => MapToResponse(x));

        public static VMTag MapToResponse(Tag tag) =>
            new VMTag
            {
                Id = tag.Id,
                Name = tag.Name
            };
    }
}
