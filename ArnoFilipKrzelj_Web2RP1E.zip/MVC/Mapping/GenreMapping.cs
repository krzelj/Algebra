﻿using API.Database;
using MVC.Models;

namespace MVC.Mapping
{
    public static class GenreMapping
    {
        public static IEnumerable<Genre> MapToDAL(IEnumerable<VMGenre> genreRequest) =>
            genreRequest.Select(x => MapToDAL(x));

        public static Genre MapToDAL(VMGenre genreRequest) =>
            new Genre
            {
                Name = genreRequest.Name,
                Description = genreRequest.Description
            };

        public static IEnumerable<VMGenre> MapToResponse(IEnumerable<Genre> genres) =>
            genres.Select(x => MapToResponse(x));

        public static VMGenre MapToResponse(Genre genre) =>
            new VMGenre
            {
                Id = genre.Id,
                Name = genre.Name,
                Description = genre.Description
            };
    }
}
