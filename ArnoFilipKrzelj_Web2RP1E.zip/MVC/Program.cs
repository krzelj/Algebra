using API.Database;
using API.Mapping;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using MVC.Models;
using MVC.Services;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<DwaMovies>(options =>
{
    options.UseSqlServer("name=Connection:DwaMovies");
});

//builder.Services.Configure<CookiePolicyOptions>(options =>
//{
//    options.MinimumSameSitePolicy = SameSiteMode.Strict;
//});

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie();

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

builder.Services.AddScoped<IRepository<VMVideo>, VideoRepository>();
builder.Services.AddScoped<IRepository<VMGenre>, GenreRepository>();
builder.Services.AddScoped<IRepository<VMTag>, TagRepository>();
builder.Services.AddScoped<IRepository<VMCountry>, CountryRepository>();
builder.Services.AddScoped<IRepository<VMGenre>, GenreRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();

var app = builder.Build();

app.UseHsts();

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Index}/{action=Index}");

app.Run();
