﻿using API.Database;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services;

namespace MVC.Controllers
{
    public class IndexController : Controller
    {
        private readonly IRepository<VMVideo> videoRepository;

        public IndexController(IRepository<VMVideo> videoRepository)
        {
            this.videoRepository = videoRepository;
        }
        public ActionResult Index()
        {
            return View(videoRepository.Retrieve().ToList());
        }

        [HttpPost]
        public ActionResult GetFilteredData(string Title)
        {
            if (Title is null)
            {
                Title = "";
            }

            var videos = videoRepository.Retrieve()
                .Where(v => v.Name.ToLower().Contains(Title.ToLower()))
                .ToList();

            return PartialView("_VideosListPartialView", videos);
        }

        public ActionResult GetFilteredDataJQuery(string term)
        {
            var filteredVideos = videoRepository.GetFilteredData(v => v.Name.ToLower().Contains(term.ToLower()));
            var labeledValues = filteredVideos.Select(x => new { value = x.Id, label = x.Name }).Take(10);

            return Json(labeledValues);
        }

        public ActionResult NotFoundPage()
        {
            return View();
        }
    }
}
