﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services;

namespace MVC.Controllers
{
    [Authorize]
    public class CountryController : Controller
    {
        private readonly IRepository<VMCountry> countryRepository;
        private readonly int pageSize = 5;
        public CountryController(IRepository<VMCountry> countryRepository)
        {
            this.countryRepository = countryRepository;
        }

        public ActionResult Index(int page, int size, string direction)
        {
            try
            {
                if (size < 1)
                {
                    size = pageSize;
                }

                var vmCountries = countryRepository.GetPagedData(page, size, x => x.Id, (direction == "ascending" || direction is null ? IFilter<VMCountry>.SortDirection.Ascending : IFilter<VMCountry>.SortDirection.Descending));

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = countryRepository.GetTotalCount();
                ViewData["pages"] = pages / size;

                return View(vmCountries);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }
    }
}
