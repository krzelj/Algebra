﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services;
using System.Security.Claims;

namespace MVC.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly int pageSize = 5;
        public UserController(IUserRepository userRepository, IHttpContextAccessor httpContextAccessor)
        {
            this.userRepository = userRepository;
            this.httpContextAccessor = httpContextAccessor;
        }

        public ActionResult Index()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Index");
                }

                return View();
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        public ActionResult Index(VMLogin login)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Index");
                }

                if (!ModelState.IsValid)
                {
                    return View(login);
                }

                var user = userRepository.GetConfirmedUser(
                login.Username,
                login.Password);

                if (user is null)
                {
                    ViewData["ErrorMessage"] = "No user found.";
                    return View(login);
                }

                var claims = new List<Claim> {
                    new Claim(ClaimTypes.Name, user.Username),
                    new Claim(ClaimTypes.Email, user.Email)
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(30),
                };

                HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    new AuthenticationProperties()).Wait();

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View(login);
            }
        }

        public ActionResult Register()
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Index");
                }

                ViewData["Countries"] = userRepository.GetCountriesList().ToList();
                return View();
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        public ActionResult Register(VMRegister register)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Index");
                }

                if (!ModelState.IsValid)
                {
                    return View(register);
                }

                userRepository.CreateUser(register);

                ViewData["EmailAddress"] = register.Email;
                return View("ConfirmAccount");
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                ViewData["Countries"] = userRepository.GetCountriesList().ToList();
                return View(register);
            }
        }

        public ActionResult ConfirmAccount()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ConfirmAccount(VMConfirmAccount confirmation)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    return RedirectToAction("Index", "Index");
                }

                userRepository.ConfirmEmail(confirmation.Email, confirmation.SecurityToken);
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View(confirmation);
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme).Wait();

            return RedirectToAction(nameof(Index));
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(VMChangePassword changePassword)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Invalid data. Please try again.");
                }

                userRepository.ChangePassword(changePassword);

                return RedirectToAction("Index", "Index");
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View(changePassword);
            }
        }

        [Authorize]
        public ActionResult MyAccount()
        {
            try
            {
                var username = httpContextAccessor.HttpContext?.User?.Identity?.Name;

                if (string.IsNullOrEmpty(username))
                {
                    return RedirectToAction("Login", "User");
                }

                var user = userRepository.GetInfo(username);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(user);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }
        [Authorize]
        public ActionResult List(int page, int size, string direction)
        {
            try
            {
                if (size < 1)
                {
                    size = pageSize;
                }

              
                var vmUsers = userRepository.GetPagedData(page, size, x => x.Id, (direction == "ascending" || direction is null ? IFilter<VMUser>.SortDirection.Ascending : IFilter<VMUser>.SortDirection.Descending));

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = userRepository.GetTotalCount();
                ViewData["pages"] = pages / size;

                ViewData["Countries"] = userRepository.GetCountriesList();

                return View(vmUsers);
            }
            catch
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }
        [Authorize]
        [HttpPost]
        public ActionResult GetFilteredData(VMUserFilter filter)
        {
            try
            {
                Func<VMUser, bool> predicate = user =>
                    (string.IsNullOrEmpty(filter.FirstName) || user.FirstName.Contains(filter.FirstName))
                    && (string.IsNullOrEmpty(filter.LastName) || user.LastName.Contains(filter.LastName))
                    && (string.IsNullOrEmpty(filter.Username) || user.Username.Contains(filter.Username))
                    && (filter.CountryId == 0 || user.Country.Id == filter.CountryId);

                var filteredUsers = userRepository.GetFilteredData(predicate);

                return PartialView("_UsersListPartialView", filteredUsers);
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }
        [Authorize]
        public ActionResult Create()
        {
             ViewData["Countries"] = userRepository.GetCountriesList();
             return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult Create(VMUser user) 
        {
            try
            {
                if (user.Password is null || user.Password.Length < 4)
                {
                    throw new Exception("Invalid data. Try again.");
                }

                var newUser = userRepository.CreateUser(new VMRegister
                {
                    Username = user.Username,
                    Email = user.Email,
                    Password = user.Password,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Phone = user.Phone,
                    CountryId = user.Country.Id,
                });

                if (user.IsConfirmed && newUser.SecurityToken is not null)
                {
                    userRepository.ConfirmEmail(newUser.Email, newUser.SecurityToken);
                }

                return RedirectToAction(nameof(List));
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View();
            }
        }
        [Authorize]
        public ActionResult Edit(int id)
        {
            try
            {
                var user = userRepository.Retrieve().FirstOrDefault(u => u.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["Countries"] = userRepository.GetCountriesList();
                return View(user);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }
        
        [Authorize]
        [HttpPost]
        public ActionResult Edit(int id, VMUser newUser)
        {
            try
            {
                userRepository.Update(id, newUser);

                return RedirectToAction(nameof(List));
            }
            catch (Exception ex)
            {

                var user = userRepository.Retrieve().FirstOrDefault(u => u.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                ViewData["Countries"] = userRepository.GetCountriesList();
                return View(user);
            }
        }

        [Authorize]
        public ActionResult Details(int id)
        {
            try
            {
                var user = userRepository.Retrieve().FirstOrDefault(v => v.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(user);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [Authorize]
        public ActionResult Delete(int id)
        {
            try
            {
                var user = userRepository.Retrieve().FirstOrDefault(v => v.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(user);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                userRepository.Delete(id);

                return RedirectToAction(nameof(List));
            }
            catch (Exception ex)
            {
                var user = userRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(user);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult SoftDelete(int id)
        {
            try
            {
                userRepository.SoftDelete(id);

                return RedirectToAction(nameof(List));
            }
            catch (Exception ex)
            {
                var user = userRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (user is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(user);
            }
        }

        [Authorize]
        public ActionResult GetFilteredUsername(string term)
        {
            var filteredUsers = userRepository.GetFilteredData(u => u.Username.ToLower().Contains(term.ToLower()));
            var labeledValues = filteredUsers.Select(x => new { value = x.Id, label = x.Username }).Take(10);

            return Json(labeledValues);
        }
        [Authorize]
        public ActionResult GetFilteredFirstName(string term)
        {
            var filteredUsers = userRepository.GetFilteredData(u => u.FirstName.ToLower().Contains(term.ToLower()));
            var distinctUsers = filteredUsers.Distinct(new VMUserComparerFirstName()).ToList();
            var labeledValues = distinctUsers.Select(x => new { value = x.Id, label = x.FirstName }).Take(10);

            return Json(labeledValues);
        }
        [Authorize]
        public ActionResult GetFilteredLastName(string term)
        {
            var filteredUsers = userRepository.GetFilteredData(u => u.LastName.ToLower().Contains(term.ToLower()));
            var distinctUsers = filteredUsers.Distinct(new VMUserComparerLastName()).ToList();
            var labeledValues = distinctUsers.Select(x => new { value = x.Id, label = x.LastName }).Take(10);

            return Json(labeledValues);
        }

    }
}
