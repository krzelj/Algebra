﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services;

namespace MVC.Controllers
{
    [Authorize]
    public class GenreController : Controller
    {
        private readonly IRepository<VMGenre> genreRepository;
        private readonly int pageSize = 5;
        public GenreController(IRepository<VMGenre> genreRepository)
        {
            this.genreRepository = genreRepository;
        }

        public ActionResult Index(int page, int size, string direction)
        {
            try
            {
                if (size < 1)
                {
                    size = pageSize;
                }

                var vmGenres = genreRepository.GetPagedData(page, size, x => x.Id, (direction == "ascending" || direction is null ? IFilter<VMGenre>.SortDirection.Ascending : IFilter<VMGenre>.SortDirection.Descending));

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = genreRepository.GetTotalCount();
                ViewData["pages"] = pages / size;

                return View(vmGenres);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        public ActionResult Details(int id)
        {
            try
            {
                var genre = genreRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (genre is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(genre);
            }
            catch (Exception)
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(VMGenre vmGenre)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Invalid data. Please input correct data.");
                }

                genreRepository.Create(vmGenre);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            try
            {
                var genre = genreRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (genre is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(genre);
            }
            catch
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, VMGenre vmGenre)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Invalid data. Please input correct data.");
                }

                genreRepository.Update(id, vmGenre);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var tag = genreRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(tag);
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                var tag = genreRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(tag);
            }
            catch 
            { 
                return RedirectToAction("NotFoundPage", "Index"); 
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                genreRepository.Delete(id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var genre = genreRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (genre is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(genre);
            }
        }
    }
}
