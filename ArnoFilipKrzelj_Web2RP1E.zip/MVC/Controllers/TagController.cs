﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services;
using System.Drawing.Printing;

namespace MVC.Controllers
{
    [Authorize]
    public class TagController : Controller
    {
        private readonly IRepository<VMTag> tagRepository;
        private readonly int pageSize = 5;
        public TagController(IRepository<VMTag> tagRepository)
        {
            this.tagRepository = tagRepository;
        }

        public ActionResult Index(int page, int size, string direction)
        {
            try
            {
                if (size < 1)
                {
                    size = pageSize;
                }

                var vmTags = tagRepository.GetPagedData(page, size, x => x.Id, (direction == "ascending" || direction is null ? IFilter<VMTag>.SortDirection.Ascending : IFilter<VMTag>.SortDirection.Descending));

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = tagRepository.GetTotalCount();
                ViewData["pages"] = pages / size;

                return View(vmTags);
            }
            catch
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        public ActionResult Details(int id)
        {
            try
            {
                var tag = tagRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(tag);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(VMTag vmTag)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Invalid data. Please input correct data.");
                }

                tagRepository.Create(vmTag);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = ex.Message;
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            try
            {
                var tag = tagRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(tag);
            }
            catch 
            { 
                return RedirectToAction("NotFoundPage", "Index"); 
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, VMTag vmTag)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    throw new Exception("Invalid data. Please input correct data.");
                }

                tagRepository.Update(id, vmTag);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var tag = tagRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(tag);
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                var tag = tagRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(tag);
            }
            catch 
            { 
                return RedirectToAction("NotFoundPage", "Index"); 
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                tagRepository.Delete(id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var tag = tagRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (tag is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(tag);
            }
        }
    }
}
