﻿using API.Database;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC.Mapping;
using MVC.Models;
using MVC.Services;

namespace MVC.Controllers
{
    [Authorize]
    public class VideoController : Controller
    {
        private readonly IRepository<VMVideo> videoRepository;
        private readonly IRepository<VMGenre> genreRepository;
        private readonly IRepository<VMTag> tagRepository;
        private readonly int pageSize = 5;
        public VideoController(IRepository<VMVideo> videoRepository, IRepository<VMGenre> genreRepository, IRepository<VMTag> tagRepository)
        {
            this.videoRepository = videoRepository;
            this.genreRepository = genreRepository;
            this.tagRepository = tagRepository;
        }

        public ActionResult Index(int page, int size, string direction)
        {
            try
            {
                if (size < 1)
                {
                    size = pageSize;
                }

                ViewData["Tags"] = tagRepository.Retrieve();
                ViewData["Genres"] = genreRepository.Retrieve();
                var vmVideos = videoRepository.GetPagedData(page, size, x => x.Id, (direction == "ascending" || direction is null ? IFilter<VMVideo>.SortDirection.Ascending : IFilter<VMVideo>.SortDirection.Descending));

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = videoRepository.GetTotalCount();
                ViewData["pages"] = pages / size;

                return View(vmVideos);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [AllowAnonymous]
        public ActionResult Details(int id)
        {
            try
            {
                var video = videoRepository.Retrieve().FirstOrDefault(v => v.Id == id);

                if (video is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(video);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        public ActionResult Create()
        {
            try
            {
                ViewData["Genres"] = genreRepository.Retrieve();
                ViewData["Tags"] = tagRepository.Retrieve();
                return View();
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreateAsync(VMVideo vmVideo, IFormFile ImageFile, int[] SelectedTags)
        {
            try
            {
                if (ImageFile != null && ImageFile.Length > 0 && SelectedTags.Length > 0)
                {
                    // Validate file type
                    var contentType = ImageFile.ContentType;
                    if (contentType != "image/jpeg" && contentType != "image/jpg")
                    {
                        throw new Exception("The file must be a JPEG image.");
                    }

                    using (var memoryStream = new MemoryStream())
                    {
                        await ImageFile.CopyToAsync(memoryStream);
                        vmVideo.Image = new Image();
                        vmVideo.Image.Content = Convert.ToBase64String(memoryStream.ToArray());
                    }
                } 
                else
                {
                    throw new Exception("Image and tags must be selected.");
                }

                var tags = tagRepository.Retrieve().Where(g => SelectedTags.Contains(g.Id));
                vmVideo.Tags = TagMapping.MapToDAL(tags).ToList();

                foreach (var tag in tags)
                {
                    vmVideo.VideoTags.Add(new VideoTag { TagId = tag.Id });
                }

                vmVideo.TotalSeconds = 100;

                videoRepository.Create(vmVideo);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewData["Genres"] = genreRepository.Retrieve();
                ViewData["Tags"] = tagRepository.Retrieve();
                ViewData["ErrorMessage"] = ex.Message;
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            try
            {
                var video = videoRepository.Retrieve().FirstOrDefault(v => v.Id == id);

                if (video is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["Genres"] = genreRepository.Retrieve();
                ViewData["Tags"] = tagRepository.Retrieve();
                return View(video);
            }
            catch 
            { 
                return RedirectToAction("NotFoundPage", "Index"); 
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> EditAsync(int id, VMUpdateVideo newVideo, IFormFile ImageFile, int[] SelectedTags)
        {
            try
            {
                if (ImageFile != null && ImageFile.Length > 0)
                {
                    // Validate file type
                    var contentType = ImageFile.ContentType;
                    if (contentType != "image/jpeg" && contentType != "image/jpg")
                    {
                        throw new Exception("The file must be a JPEG image.");
                    }

                    using (var memoryStream = new MemoryStream())
                    {
                        await ImageFile.CopyToAsync(memoryStream);
                        newVideo.Image = new Image();
                        newVideo.Image.Content = Convert.ToBase64String(memoryStream.ToArray());
                    }
                }

                if (SelectedTags.Length == 0)
                {
                    throw new Exception("You must have at least one selected tag.");
                }

                var tags = tagRepository.Retrieve().Where(g => SelectedTags.Contains(g.Id));
                newVideo.Tags = TagMapping.MapToDAL(tags).ToList();

                foreach (var tag in tags)
                {
                    newVideo.VideoTags.Add(new VideoTag { TagId = tag.Id });
                }

                var video = videoRepository.Update(id, new VMVideo
                {
                    Name = newVideo.Name,
                    Description = newVideo.Description,
                    Genre = newVideo.Genre,
                    GenreId = newVideo.GenreId,
                    Image = newVideo.Image,
                    VideoTags = newVideo.VideoTags,
                    Tags = newVideo.Tags
                });

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var video = videoRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (video is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                ViewData["Genres"] = genreRepository.Retrieve();
                ViewData["Tags"] = tagRepository.Retrieve();
                return View(video);
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                var video = videoRepository.Retrieve().FirstOrDefault(v => v.Id == id);

                if (video is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                return View(video);
            }
            catch 
            {
                return RedirectToAction("NotFoundPage", "Index");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                videoRepository.Delete(id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var video = videoRepository.Retrieve().FirstOrDefault(t => t.Id == id);

                if (video is null)
                {
                    return RedirectToAction("NotFoundPage", "Index");
                }

                ViewData["ErrorMessage"] = ex.Message;
                return View(video);
            }
        }

        public ActionResult GetFilteredDataJQuery(string term)
        {
            var filteredVideos = videoRepository.GetFilteredData(v => v.Name.ToLower().Contains(term.ToLower()) || v.Description.Contains(term));
            var labeledValues = filteredVideos.Select(x => new { value = x.Id, label = x.Name }).Take(10);

            return Json(labeledValues);
        }

        [HttpPost]
        public ActionResult GetFilteredData(VMFilter filter)
        {
            ViewData["Genres"] = genreRepository.Retrieve();
            ViewData["Tags"] = tagRepository.Retrieve();

            try
            {
                Func<VMVideo, bool> predicate = video =>
                    (filter.Id == 0 || video.Id == filter.Id) &&
                    (string.IsNullOrEmpty(filter.Title) || video.Name.Contains(filter.Title)) &&
                    (filter.GenreId == 0 || video.GenreId == filter.GenreId) &&
                    (filter.SelectedTags == null || filter.SelectedTags.All(tagId => video.Tags.Any(tag => tag.Id == tagId)));

                var vmVideos = videoRepository.GetFilteredData(predicate);

                return PartialView("_VideosListPartialView", vmVideos);
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }

        /*public ActionResult GetFilteredData(VMFilter filter, int page, int size, string direction)
        {
            ViewData["Genres"] = genreRepository.Retrieve();
            ViewData["Tags"] = tagRepository.Retrieve();

            try
            {
                Func<VMVideo, bool> predicate = video =>
                    (filter.Id == 0 || video.Id == filter.Id) &&
                    (string.IsNullOrEmpty(filter.Title) || video.Name.Contains(filter.Title)) &&
                    (filter.GenreId == 0 || video.GenreId == filter.GenreId) &&
                    (filter.SelectedTags == null || filter.SelectedTags.All(tagId => video.Tags.Any(tag => tag.Id == tagId)));

                var vmVideos = videoRepository.GetFilteredData(predicate).Skip(page * size).Take(size);

                if (direction == "ascending")
                {
                    vmVideos.OrderBy(x => x.Id);
                } else
                {
                    vmVideos.OrderByDescending(x => x.Id);
                }

                ViewData["page"] = page;
                ViewData["size"] = size;
                ViewData["direction"] = direction;
                var pages = vmVideos.Count();
                ViewData["pages"] = pages / size;

                ViewData["Id"] = filter.Id;
                ViewData["Title"] = filter.Title;
                ViewData["Tags"] = filter.SelectedTags;
                ViewData["Genre"] = filter.GenreId;
                
                return PartialView("_VideosListPartialView", vmVideos);
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }*/
    }
}
