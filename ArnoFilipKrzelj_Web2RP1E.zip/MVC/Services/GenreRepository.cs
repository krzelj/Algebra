﻿using API.Database;
using Microsoft.EntityFrameworkCore;
using MVC.Mapping;
using MVC.Models;

namespace MVC.Services
{
    public class GenreRepository : IRepository<VMGenre>
    {
        private readonly DwaMovies database;
        public GenreRepository(DwaMovies database)
        {
            this.database = database;
        }

        public VMGenre Create(VMGenre model)
        {
            try
            {
                database.Genres.Add(GenreMapping.MapToDAL(model));
                database.SaveChanges();

                return model;
            }
            catch
            {
                throw new Exception("Failed to create genre.");
            }
        }

        public VMGenre Delete(int id)
        {
            try
            {
                var genre = database.Genres.FirstOrDefault(v => v.Id == id);

                if (genre is null)
                {
                    throw new Exception();
                }

                // This won't work unless no videos have a reference to that genre. 
                // If I wanted this to work no matter what, I would delete all videos that have this genreId, which is not good.
                // var videos = database.Videos.Where(v => v.GenreId == genre.Id);
                // database.Videos.RemoveRange(videos);


                database.Genres.Remove(genre);
                database.SaveChanges();

                return GenreMapping.MapToResponse(genre);
            }
            catch
            {
                throw new Exception("Failed to delete genre.");
            }
        }

        public IEnumerable<VMGenre> GetFilteredData(Func<VMGenre, bool> filter)
        {
            try
            {
                if (filter == null)
                {
                    throw new Exception(nameof(filter));
                }

                return Retrieve().Where(filter);
            }
            catch 
            {
                throw new Exception("Failed to filter genres.");
            }
        }

        public IEnumerable<VMGenre> GetPagedData(int page, int size, Func<VMGenre, object> orderBy, IFilter<VMGenre>.SortDirection direction)
        {
            try
            {
                if (page < 0) throw new ArgumentOutOfRangeException(nameof(page), "Page must be at least 0.");
                if (size < 1) throw new ArgumentOutOfRangeException(nameof(size), "Size must be at least 1.");
                if (orderBy == null) throw new ArgumentNullException(nameof(orderBy), "Specified order is invalid.");

                var query = Retrieve();

                if (direction == IFilter<VMGenre>.SortDirection.Ascending)
                {
                    query = query.OrderBy(orderBy);
                }
                else
                {
                    query = query.OrderByDescending(orderBy);
                }

                query = query.Skip(page * size).Take(size);

                return query.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int GetTotalCount(Func<VMGenre, bool> filter = null)
        {
            try
            {
                if (filter == null)
                {
                    return Retrieve().Count();
                }

                return Retrieve().Where(filter).Count();
            }
            catch
            {
                throw new Exception("Failed to get count of filtered genres.");
            }
        }

        public IEnumerable<VMGenre> Retrieve()
        {
            try
            {
                var genres = database.Genres;

                var vmGenres = GenreMapping.MapToResponse(genres);

                return vmGenres;
            }
            catch
            {
                throw new Exception("Failed to retrieve genres.");
            }
        }

        public VMGenre Update(int id, VMGenre model)
        {
            try
            {
                var genre = database.Genres.FirstOrDefault(v => v.Id == id);

                if (genre is null)
                {
                    return null;
                }

                genre.Name = model.Name;
                genre.Description = model.Description;

                database.SaveChanges();

                return GenreMapping.MapToResponse(genre);
            }
            catch
            {
                throw new Exception("Failed to update genre.");
            }
        }
    }
}
