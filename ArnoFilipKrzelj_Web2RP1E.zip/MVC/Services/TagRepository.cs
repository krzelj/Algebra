﻿using API.Database;
using Microsoft.Build.Framework;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using MVC.Mapping;
using MVC.Models;

namespace MVC.Services
{
    public class TagRepository : IRepository<VMTag>
    {
        private readonly DwaMovies database;
        public TagRepository(DwaMovies database)
        {
            this.database = database;
        }

        public VMTag Create(VMTag model)
        {
            try
            {
                database.Tags.Add(TagMapping.MapToDAL(model));
                database.SaveChanges();

                return model;
            }
            catch
            {
                throw new Exception("Failed to create tag.");
            }
        }

        public VMTag Delete(int id)
        {
            try
            {
                var tag = database.Tags.FirstOrDefault(v => v.Id == id);

                if (tag is null)
                {
                    throw new Exception();
                }


                var existingTags = database.VideoTags.Where(vt => vt.TagId == tag.Id);
                database.VideoTags.RemoveRange(existingTags);

                database.Tags.Remove(tag);
                database.SaveChanges();

                return TagMapping.MapToResponse(tag);
            }
            catch
            {
                throw new Exception("Failed to delete tag.");
            }
        }

        public IEnumerable<VMTag> GetFilteredData(Func<VMTag, bool> filter)
        {
            try
            {
                if (filter == null)
                {
                    throw new Exception(nameof(filter));
                }

                return Retrieve().Where(filter);
            }
            catch
            {
                throw new Exception("Failed to filter tags.");
            }
        }

        public IEnumerable<VMTag> GetPagedData(int page, int size, Func<VMTag, object> orderBy, IFilter<VMTag>.SortDirection direction)
        {
            try
            {
                if (page < 0) throw new ArgumentOutOfRangeException(nameof(page), "Page must be at least 0.");
                if (size < 1) throw new ArgumentOutOfRangeException(nameof(size), "Size must be at least 1.");
                if (orderBy == null) throw new ArgumentNullException(nameof(orderBy), "Specified order is invalid.");

                var query = Retrieve();

                if (direction == IFilter<VMTag>.SortDirection.Ascending)
                {
                    query = query.OrderBy(orderBy);
                }
                else
                {
                    query = query.OrderByDescending(orderBy);
                }

                query = query.Skip(page * size).Take(size);

                return query.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int GetTotalCount(Func<VMTag, bool> filter = null)
        {
            try
            {
                if (filter == null)
                {
                    return Retrieve().Count();
                }

                return Retrieve().Where(filter).Count();
            }
            catch
            {
                throw new Exception("Failed to get count of filtered tags.");
            }
        }

        public IEnumerable<VMTag> Retrieve()
        {
            try
            {
                var tags = database.Tags;

                var vmTags = TagMapping.MapToResponse(tags);

                return vmTags;
            }
            catch
            {
                throw new Exception("Failed to retrieve tags.");
            }
        }

        public VMTag Update(int id, VMTag model)
        {
            try
            {
                var tag = database.Tags.FirstOrDefault(v => v.Id == id);

                if (tag is null)
                {
                    throw new Exception();
                }

                tag.Name = model.Name;

                database.SaveChanges();

                return TagMapping.MapToResponse(tag);
            }
            catch
            {
                throw new Exception("Failed to update tag.");
            }
        }
    }
}
