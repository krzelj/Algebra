﻿using API.Database;
using API.Mapping;
using Microsoft.EntityFrameworkCore;
using MVC.Models;
using System.Linq;

namespace MVC.Services
{
    public class VideoRepository : IRepository<VMVideo>
    {
        private readonly DwaMovies database;
        public VideoRepository(DwaMovies database)
        {
            this.database = database;
        }

        public VMVideo Create(VMVideo model)
        {
            try
            {
                model.CreatedAt = DateTime.Now;
             
                database.Videos.Add(VideoMapping.MapToDAL(model));
                database.SaveChanges();

                return model;
            }
            catch 
            {
                throw new Exception("Failed to create video.");
            }
        }

        public VMVideo Delete(int id)
        {
            try
            {
                var video = database.Videos.FirstOrDefault(v => v.Id == id);

                if (video is null)
                {
                    throw new Exception();
                }

                var videoTags = database.VideoTags.Where(vt => vt.VideoId == video.Id);

                if (videoTags.Any())
                {
                    database.VideoTags.RemoveRange(videoTags);
                }

                var image = database.Images.FirstOrDefault(img => img.Id == video.ImageId);
                if (image is not null)
                {
                    database.Images.Remove(image);
                }

                database.Videos.Remove(video);
                database.SaveChanges();

                return VideoMapping.MapToResponse(video);
            }
            catch 
            {
                throw new Exception("Failed to delete video.");
            }
        }

        public IEnumerable<VMVideo> GetFilteredData(Func<VMVideo, bool> filter)
        {
            try
            {
                if (filter == null)
                {
                    throw new Exception(nameof(filter));
                }

                return Retrieve().Where(filter);
            }
            catch 
            {
                throw new Exception("Failed to filter videos.");
            }
        }

        public IEnumerable<VMVideo> GetPagedData(int page, int size, Func<VMVideo, object> orderBy, IFilter<VMVideo>.SortDirection direction)
        {
            try
            {
                if (page < 0) throw new ArgumentOutOfRangeException(nameof(page), "Page must be at least 0.");
                if (size < 1) throw new ArgumentOutOfRangeException(nameof(size), "Size must be at least 1.");
                if (orderBy == null) throw new ArgumentNullException(nameof(orderBy), "Order is invalid.");

                var query = Retrieve();

                if (direction == IFilter<VMVideo>.SortDirection.Ascending)
                {
                    query = query.OrderBy(orderBy);
                }
                else 
                {
                    query = query.OrderByDescending(orderBy);
                }

                query = query.Skip(page * size).Take(size);

                return query.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int GetTotalCount(Func<VMVideo, bool> filter = null)
        {
            try
            {
                if (filter == null)
                {
                    return Retrieve().Count();
                }

                return Retrieve().Where(filter).Count();
            }
            catch
            {
                throw new Exception("Failed to get count of filtered videos.");
            }
        }

        public IEnumerable<VMVideo> Retrieve()
        {
            try
            {
                var videos = database.Videos
                    .Include(v => v.Genre)
                    .Include(v => v.Image)
                    .Include(v => v.VideoTags)
                        .ThenInclude(vt => vt.Tag);  

                var vmVideos = VideoMapping.MapToResponse(videos);

                return vmVideos;
            } 
            catch
            {
                throw new Exception("Failed to retrieve videos.");
            }
        }


        public VMVideo Update(int id, VMVideo model)
        {
            try
            {
                var video = database.Videos.FirstOrDefault(v => v.Id == id);

                if (video is null)
                {
                    throw new Exception();
                }

                video.Name = model.Name;
                video.Description = model.Description;
                video.GenreId = model.GenreId;
                
                var existingTags = database.VideoTags.Where(vt => vt.VideoId == video.Id);
                database.VideoTags.RemoveRange(existingTags);

                video.VideoTags = model.VideoTags;

                if (model.Image is not null)
                {
                    video.Image = model.Image;  
                }

                database.SaveChanges();

                return VideoMapping.MapToResponse(video);
            }
            catch 
            {
                throw new Exception("Failed to update video.");
            }
        }
    }
}
