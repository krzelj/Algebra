﻿using API.Database;
using MVC.Mapping;
using MVC.Models;

namespace MVC.Services
{
    public class CountryRepository : IRepository<VMCountry>
    {
        private readonly DwaMovies database;
        public CountryRepository(DwaMovies database)
        {
            this.database = database;

        }
        public VMCountry Create(VMCountry model)
        {
            try
            {
                database.Countries.Add(CountryMapping.MapToDAL(model));

                database.SaveChanges();

                return model;
            }
            catch
            {
                throw new Exception("Failed to create country.");
            }
        }

        public VMCountry Delete(int id)
        {
            try
            {
                var country = database.Countries.FirstOrDefault(v => v.Id == id);

                if (country is null)
                {
                    throw new Exception();
                }

                database.Countries.Remove(country);
                database.SaveChanges();

                return CountryMapping.MapToResponse(country);
            }
            catch
            {
                throw new Exception("Failed to delete country.");
            }
        }

        public IEnumerable<VMCountry> GetFilteredData(Func<VMCountry, bool> filter)
        {
            try
            {
                if (filter == null)
                {
                    throw new Exception(nameof(filter));
                }

                return Retrieve().Where(filter);
            }
            catch
            {
                throw new Exception("Failed to filter countries.");
            }
        }

        public IEnumerable<VMCountry> GetPagedData(int page, int size, Func<VMCountry, object> orderBy, IFilter<VMCountry>.SortDirection direction)
        {
            try
            {
                if (page < 0) throw new ArgumentOutOfRangeException(nameof(page), "Page must be at least 0.");
                if (size < 1) throw new ArgumentOutOfRangeException(nameof(size), "Size must be at least 1.");
                if (orderBy == null) throw new ArgumentNullException(nameof(orderBy), "Specified order is invalid.");

                var query = Retrieve();

                if (direction == IFilter<VMCountry>.SortDirection.Ascending)
                {
                    query = query.OrderBy(orderBy);
                }
                else
                {
                    query = query.OrderByDescending(orderBy);
                }

                query = query.Skip(page * size).Take(size);

                return query.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int GetTotalCount(Func<VMCountry, bool> filter = null)
        {
            try
            {
                if (filter == null)
                {
                    return Retrieve().Count();
                }

                return Retrieve().Where(filter).Count();
            }
            catch
            {
                throw new Exception("Failed to get count of filtered countries.");
            }
        }

        public IEnumerable<VMCountry> Retrieve()
        {
            try
            {
                var countries = database.Countries;

                var vmCountries = CountryMapping.MapToResponse(countries);

                return vmCountries;
            }
            catch
            {
                throw new Exception("Failed to retrieve countries.");
            }
        }

        public VMCountry Update(int id, VMCountry model)
        {
            try
            {
                var country = database.Countries.FirstOrDefault(v => v.Id == id);

                if (country is null)
                {
                    return null;
                }

                country.Code = model.Code;
                country.Name = model.Name;

                database.SaveChanges();

                return CountryMapping.MapToResponse(country);
            }
            catch
            {
                throw new Exception("Failed to update country.");
            }
        }
    }
}
