﻿using API.Database;
using MVC.Models;

namespace MVC.Services
{
    public interface IUserRepository : IRepository<VMUser>
    {
        IEnumerable<VMUser> GetAll();
        VMUser CreateUser(VMRegister register);
        void ConfirmEmail(string email, string securityToken);
        VMUser GetConfirmedUser(string username, string password);
        void ChangePassword(VMChangePassword changePassword);
        IEnumerable<Country> GetCountriesList();
        void SoftDelete(int id);
        VMUser GetInfo(string username);
    }
}
