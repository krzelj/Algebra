﻿using MVC.Models;

namespace MVC.Services
{
    public interface IRepository<T> : IFilter<T>
    {
        IEnumerable<T> Retrieve();
        T Create(T model);
        T Update(int id, T model);
        T Delete(int id);
    }
}
