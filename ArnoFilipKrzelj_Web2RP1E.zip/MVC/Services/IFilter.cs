﻿namespace MVC.Services
{
    public interface IFilter<T> 
    {
        public enum SortDirection
        {
            Ascending,
            Descending
        }
        IEnumerable<T> GetFilteredData(Func<T, bool> filter);
        IEnumerable<T> GetPagedData(int page, int size, Func<T, object> orderBy, SortDirection direction);
        int GetTotalCount(Func<T, bool> filter = null);
    }
}
