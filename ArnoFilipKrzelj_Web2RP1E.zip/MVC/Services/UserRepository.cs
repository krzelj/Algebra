﻿using API.Database;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using MVC.Mapping;
using MVC.Models;
using RestSharp;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace MVC.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly DwaMovies database;
        public UserRepository(DwaMovies database)
        {
            this.database = database;
        }

        public void ChangePassword(VMChangePassword changePassword)
        {
            try
            {
                var user = database.Users.FirstOrDefault(x =>
               x.Username == changePassword.Username &&
               !x.DeletedAt.HasValue);

                if (user is null)
                {
                    throw new Exception();
                }

                var oldSalt = Convert.FromBase64String(user.PwdSalt);
                var oldB64Hash = CreateHash(changePassword.Password, oldSalt);

                if (oldB64Hash != user.PwdHash)
                {
                    throw new Exception();
                }

                (var salt, var b64Salt) = GenerateSalt();
                var b64Hash = CreateHash(changePassword.NewPassword, salt);

                user.PwdHash = b64Hash;
                user.PwdSalt = b64Salt;

                database.SaveChanges();
            }
            catch 
            {
                throw new Exception("Failed to change password.");
            }
        }

        public void ConfirmEmail(string email, string securityToken)
        {
            try
            {
                var user = database.Users.FirstOrDefault(x =>
                x.Email == email &&
                x.SecurityToken == securityToken);

                if (user is null)
                {
                    throw new Exception();
                }

                user.IsConfirmed = true;

                database.SaveChanges();
            }
            catch 
            {
                throw new Exception("Failed to confirm E-mail address.");
            }
        }

        public VMUser CreateUser(VMRegister register)
        {
            try
            {
                if (database.Users.Any(user => user.Username == register.Username))
                {
                    throw new Exception();
                }
                (var salt, var b64Salt) = GenerateSalt();
                var b64Hash = CreateHash(register.Password, salt);
                var b64SecToken = GenerateSecurityToken();

                // Create BLUser object
                var newUser = new User()
                {
                    CreatedAt = DateTime.UtcNow,
                    Username = register.Username,
                    FirstName = register.FirstName,
                    LastName = register.LastName,
                    Phone = register.Phone,
                    Email = register.Email,
                    CountryOfResidenceId = register.CountryId,
                    PwdHash = b64Hash,
                    PwdSalt = b64Salt,
                    SecurityToken = b64SecToken,
                    CountryOfResidence = database.Countries.FirstOrDefault(c => c.Id == register.CountryId)
                };

                database.Users.Add(newUser);

                database.SaveChanges();

                SendEmail(newUser);

                var blUser = UserMapping.MapToResponse(newUser);

                return blUser;
            }
            catch 
            {
                throw new Exception("Username already exists.");
            }
        }

        private void SendEmail(User newUser)
        {
            var client = new RestClient("https://api.mailgun.net/v3");

            var request = new RestRequest("sandboxedaee27328a8453bbacf4b8bfef9a201.mailgun.org/messages", RestSharp.Method.Post);
            request.AddHeader("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes("api:c75e68834262ef3e55ee3cac27e0c1f0-135a8d32-c74912ca")));
            request.AddParameter("from", "Excited User <mailgun@sandboxedaee27328a8453bbacf4b8bfef9a201.mailgun.org>");
            request.AddParameter("to", newUser.Email);
            request.AddParameter("subject", $"Confirm your account for {newUser.Username}");
            request.AddParameter("html", $"<h1>Welcome to Ghimli.tv!</h1><p>Thanks for joining. Here's your security token: {newUser.SecurityToken}</p>");

            var response = client.Execute(request);
        }

        public IEnumerable<VMUser> GetAll()
        {
            try
            {
                var users = database.Users.Include(c => c.CountryOfResidence);

                var vmUsers = UserMapping.MapToResponse(users);

                return vmUsers;
            }
            catch 
            {
                throw new Exception("Failed to get users.");
            }
        }

        public VMUser GetConfirmedUser(string username, string password)
        {
            try
            {
                var user = database.Users.Include(u => u.CountryOfResidence).FirstOrDefault(x =>
                x.Username == username);

                if (user is null)
                {
                    throw new Exception("Username or password is invalid.");
                }
                else if (user.IsConfirmed is false)
                {
                    throw new Exception("Account has not been confirmed. Please check your E-mail address.");
                }
                else if (user.DeletedAt is not null)
                {
                    throw new Exception("Account has been deactivated. To activate your account, please contact support.");
                }

                var salt = Convert.FromBase64String(user.PwdSalt);
                var b64Hash = CreateHash(password, salt);

                if (user.PwdHash != b64Hash)
                    throw new Exception("Username or password is invalid.");

                var blUser = UserMapping.MapToResponse(user);

                return blUser;
            }
            catch (Exception ex)
            { 
                throw new Exception(ex.Message); 
            }
        }

        private static (byte[], string) GenerateSalt()
        {
            // Generate salt
            var salt = RandomNumberGenerator.GetBytes(128 / 8);
            var b64Salt = Convert.ToBase64String(salt);

            return (salt, b64Salt);
        }

        private static string CreateHash(string password, byte[] salt)
        {
            // Create hash from password and salt
            byte[] hash =
                KeyDerivation.Pbkdf2(
                    password: password,
                    salt: salt,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: 100000,
                    numBytesRequested: 256 / 8);
            string b64Hash = Convert.ToBase64String(hash);

            return b64Hash;
        }

        private static string GenerateSecurityToken()
        {
            byte[] securityToken = RandomNumberGenerator.GetBytes(256 / 8);
            string b64SecToken = Convert.ToBase64String(securityToken);

            return b64SecToken;
        }

        public IEnumerable<Country> GetCountriesList()
        {
            try
            {
                var countries = database.Countries;

                return countries;
            }
            catch (Exception)
            {
                throw new Exception("Failed to get countries.");
            }
        }

        public VMUser GetInfo(string username)
        {
            try
            {
                var user = database.Users.Include(c => c.CountryOfResidence).FirstOrDefault(user => user.Username == username);

                if (user is null)
                {
                    return null;
                }

                return UserMapping.MapToResponse(user);
            }
            catch
            {
                throw new Exception("Failed to fetch user.");
            }
        }

        public IEnumerable<VMUser> Retrieve()
        {
            try
            {
                var users = database.Users
                    .Include(u => u.CountryOfResidence);

                var vmUsers = UserMapping.MapToResponse(users);

                return vmUsers;
            }
            catch
            {
                throw new Exception("Failed to retrieve videos.");
            }
        }

        public VMUser Create(VMUser model)
        {
            try
            {
                var newUser = CreateUser(new VMRegister
                {
                    Username = model.Username,
                    Password = model.Password,
                    Email = model.Email,
                    Phone = model.Phone,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    CountryId = model.Country.Id
                });

                return newUser;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public VMUser Update(int id, VMUser model)
        {
            try
            {
                var user = database.Users.Include(c => c.CountryOfResidence).FirstOrDefault(v => v.Id == id);

                if (user is null)
                {
                    throw new Exception("User does not exist.");
                }

                if (database.Users.Any(u => u.Username == model.Username && u.Id != user.Id))
                {
                    throw new Exception("Username already exists. Update failed.");
                }
                else
                {
                    user.Username = model.Username;
                }

                if (model.Password is not null)
                {
                    (var salt, var b64Salt) = GenerateSalt();
                    var b64Hash = CreateHash(model.Password, salt);

                    user.PwdHash = b64Hash;
                    user.PwdSalt = b64Salt;
                }

                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.Email = model.Email;
                user.Phone = model.Phone;
                user.CountryOfResidenceId = model.Country.Id;
                user.IsConfirmed = model.IsConfirmed;
               
                database.SaveChanges();

                return UserMapping.MapToResponse(user);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public VMUser Delete(int id)
        {
            try
            {
                var user = database.Users.Include(u => u.CountryOfResidence).FirstOrDefault(v => v.Id == id);

                if (user is null)
                {
                    throw new Exception();
                }

                database.Users.Remove(user);               

                database.SaveChanges();

                return UserMapping.MapToResponse(user);
            }
            catch
            {
                throw new Exception("Failed to delete user.");
            }
        }

        public IEnumerable<VMUser> GetFilteredData(Func<VMUser, bool> filter)
        {
            try
            {
                if (filter == null)
                {
                    throw new Exception(nameof(filter));
                }

                return Retrieve().Where(filter);
            }
            catch
            {
                throw new Exception("Failed to filter videos.");
            }
        }

        public IEnumerable<VMUser> GetPagedData(int page, int size, Func<VMUser, object> orderBy, IFilter<VMUser>.SortDirection direction)
        {
            try
            {
                if (page < 0) throw new ArgumentOutOfRangeException(nameof(page), "Page must be at least 0.");
                if (size < 1) throw new ArgumentOutOfRangeException(nameof(size), "Size must be at least 1.");
                if (orderBy == null) throw new ArgumentNullException(nameof(orderBy), "Order is invalid.");

                var query = Retrieve();

                if (direction == IFilter<VMUser>.SortDirection.Ascending)
                {
                    query = query.OrderBy(orderBy);
                }
                else
                {
                    query = query.OrderByDescending(orderBy);
                }

                query = query.Skip(page * size).Take(size);

                return query.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int GetTotalCount(Func<VMUser, bool> filter = null)
        {
            try
            {
                if (filter == null)
                {
                    return Retrieve().Count();
                }

                return Retrieve().Where(filter).Count();
            }
            catch
            {
                throw new Exception("Failed to get count of filtered users.");
            }
        }

        public void SoftDelete(int id)
        {
            try
            {
                var user = database.Users.FirstOrDefault(u => u.Id == id);

                if (user is null)
                {
                    throw new Exception();
                }

                user.DeletedAt = DateTime.Now;
                database.SaveChanges();
            }
            catch (Exception)
            {
                throw new Exception("Failed to deactivate user.");
            }
        }
    }
}
